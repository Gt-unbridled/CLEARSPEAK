export default function ChatIndexPage() {
  return (
    <div className="flex-1 flex items-center justify-center px-6">
      <div className="max-w-[420px] text-center">
        <h1 className="text-2xl font-bold mb-3">Pick a conversation</h1>
        <p className="text-ink-soft">
          Choose someone from the sidebar, or start a new conversation by
          email.
        </p>
      </div>
    </div>
  );
}
