import Link from "next/link";
import AuthForm from "@/app/auth-form";

export default function LoginPage() {
  return (
    <main className="flex-1 max-w-[720px] mx-auto px-6 py-16 w-full">
      <p className="text-sage-deep font-bold mb-3">ClearSpeak</p>
      <h1 className="text-3xl font-bold mb-3">Welcome back</h1>
      <p className="text-ink-soft mb-10 max-w-[440px]">
        Good to see you.
      </p>
      <AuthForm mode="login" />
      <p className="text-ink-soft mt-8">
        New here?{" "}
        <Link href="/signup" className="text-sage-deep font-bold">
          Create an account
        </Link>
      </p>
    </main>
  );
}
