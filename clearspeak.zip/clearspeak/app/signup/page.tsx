import Link from "next/link";
import AuthForm from "@/app/auth-form";

export default function SignupPage() {
  return (
    <main className="flex-1 max-w-[720px] mx-auto px-6 py-16 w-full">
      <p className="text-sage-deep font-bold mb-3">ClearSpeak</p>
      <h1 className="text-3xl font-bold mb-3">Create your account</h1>
      <p className="text-ink-soft mb-10 max-w-[440px]">
        Takes a minute. No pressure to fill anything out perfectly.
      </p>
      <AuthForm mode="signup" />
      <p className="text-ink-soft mt-8">
        Already have an account?{" "}
        <Link href="/login" className="text-sage-deep font-bold">
          Log in
        </Link>
      </p>
    </main>
  );
}
