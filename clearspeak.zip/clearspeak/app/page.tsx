import Link from "next/link";

export default function Home() {
  return (
    <main className="flex-1">
      {/* Hero */}
      <section className="max-w-[720px] mx-auto px-6 pt-20 pb-16">
        <p className="text-sage-deep font-bold mb-6">ClearSpeak</p>
        <h1 className="text-[2.75rem] leading-[1.15] font-bold text-ink mb-6 max-w-[600px]">
          Say it your way. Hear it clearly.
        </h1>
        <p className="text-lg text-ink-soft max-w-[520px] mb-10">
          Most messaging apps assume fast reading and fast typing. ClearSpeak
          doesn&apos;t. Speak your messages instead of typing them. Hear every
          reply instead of decoding it. No red squiggles, no pressure.
        </p>
        <div className="flex gap-4 items-center">
          <Link
            href="/signup"
            className="bg-sage hover:bg-sage-deep text-white px-6 py-3 rounded-lg font-bold transition-colors"
          >
            Create your account
          </Link>
          <Link
            href="/login"
            className="text-ink-soft hover:text-ink px-4 py-3 font-bold"
          >
            Log in
          </Link>
        </div>
      </section>

      {/* Why - the real research, stated plainly */}
      <section className="border-t border-line bg-panel">
        <div className="max-w-[720px] mx-auto px-6 py-16">
          <h2 className="text-2xl font-bold mb-8">Why this exists</h2>
          <div className="space-y-6 max-w-[560px]">
            <p className="text-ink-soft">
              Dyslexia isn&apos;t just about reading. In a 2025 survey, 67%
              of dyslexic adults said live conversation — meetings, group
              chats, quick replies — was harder than written tasks.
            </p>
            <p className="text-ink-soft">
              Working memory gets stretched thin: finding the right word
              under pressure, holding onto several ideas in a thread, typing
              fast enough that a reply doesn&apos;t feel late.
            </p>
            <p className="text-ink-soft">
              Most tools respond with a font change. ClearSpeak rebuilds the
              conversation itself — voice in, speech out, and a gentle
              simplify option when a message runs long.
            </p>
          </div>
        </div>
      </section>

      {/* What it does - three real features, plainly named */}
      <section className="max-w-[720px] mx-auto px-6 py-16">
        <div className="space-y-10">
          <div className="flex gap-5">
            <div className="w-1 bg-clay rounded-full shrink-0" />
            <div>
              <h3 className="font-bold text-lg mb-1">Speak, don&apos;t type</h3>
              <p className="text-ink-soft">
                Record a message and it&apos;s transcribed for you. No blank
                text box staring back.
              </p>
            </div>
          </div>
          <div className="flex gap-5">
            <div className="w-1 bg-sage rounded-full shrink-0" />
            <div>
              <h3 className="font-bold text-lg mb-1">Listen to any reply</h3>
              <p className="text-ink-soft">
                Every message can be read aloud, one tap, at your pace.
              </p>
            </div>
          </div>
          <div className="flex gap-5">
            <div className="w-1 bg-ink-soft rounded-full shrink-0" />
            <div>
              <h3 className="font-bold text-lg mb-1">Simplify on request</h3>
              <p className="text-ink-soft">
                Long or dense messages can be shortened into plain language,
                only when you want it.
              </p>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
